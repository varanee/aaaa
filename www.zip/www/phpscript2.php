<html>
    <head>
        <title><?php echo ("php2");?></title>
    </head>
        <body>
            <?php
                $name="John";
                echo "Welcome $name <br/>";
                $a=10;
                $b=20;
                echo "Sum of $a and $b is";
                echo $a+$b;
            ?>
        </body>
</html>