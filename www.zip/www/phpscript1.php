<html>
    <head>
        <title><?php echo date("l/d-m-Y");?></title>
    </head>
    <body>
        <h1>Bintu Online Bazar</h1>
        <?php
            echo '<b>Welcome to our store</b>';
        ?>
    </body>
</html>