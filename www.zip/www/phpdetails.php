<?php
    phpinfo(); //รันคำสั่ง php
?>