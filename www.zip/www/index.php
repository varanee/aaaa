
<?php
include('topmenu.php');
?>
<span id="crossfade">
<a href="itemlist.php?category=CellPhone">
<img class="bottom" src="images/iphoneX.png"
style="max-width:350px;max-height:350px;width:auto; height:auto;" />
<img class="top" src="images/iphonese.png"
style="max-width:350px;max-height:350px;width: auto;height: auto;" /></a>
</span>
<span id="crossfade">
<a href="itemlist.php?category=CellPhone">
<img class="bottom" src="images/iphone6s.png"
style="max-width:350px;max-height:350px;width:auto; height: auto;" />
<img class="top" src="images/250x270_1.png"
style="max-width:350px;max-height:350px;width:auto;height: auto;" /></a>
</span>
<span id="crossfade">
<a href="itemlist.php?category=Laptop">
<img class="bottom" src="images/laptop_PNG5940.png"
style="max-width:350px;max-height:350px;width:auto;height: auto;" />
<img class="top" src="images/laptop_PNG5931.png"
style="max-width:350px;max-height:350px;width:auto;height: auto;" /></a>
</span>
</body>
</html>