<html>
    <head>
    </head>
        <body>
            <form action="phpscript33.php" method="Get">
            Name: <input type="text" name="name" /><br/><br/>
            Email address: <input type="text" name="email_add" /><br/><br/>
            <input type="submit" value="Submit" />
            </form>
        </body>
</html>